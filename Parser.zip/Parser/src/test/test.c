#include <stdio.h>

int main(void){
    int a = 5;
    int b = 3;
    int c = a + b;
}