package Exceptions;

public class UnkwnonInstructionException extends Exception{
    public UnkwnonInstructionException(String message) {
        super(message);
    }
}
