package Exceptions;

public class ErrorOnInstruction extends Exception {
    public ErrorOnInstruction(String message) {
        super(message);
    }
}
